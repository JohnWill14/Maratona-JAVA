package br.com.william.estruturadedados.livro.inicio;

public class Comentarios{
	//Comentario de uma linha

	/*
	Bloco de comentario

	*/
	/**
	* Comentario usado pelo JAVADOC, para documentacao
	*
	*/
}
