package br.com.william.estruturadedados.livro.inicio;
public class Tipos{
	public static void main(String args[]){
		boolean verdadeiro=20>10;
		char caractere='A';
		byte b=12;
		short s=24;
		int i=257;
		long l=890l;// Observar o uso do L aqui
		float f=3.1415f; // Observar o uso do f
		double d=2.1828;
		System.out.println("verdade : "+verdadeiro);//'+' concatena strings
		System.out.println("caractere : "+caractere);
		System.out.println("b : "+b);
		System.out.println("s : "+s);
		System.out.println("i : "+i);
		System.out.println("l : "+l);
		System.out.println("f : "+f);
		System.out.println("d : "+d);
	}

}
