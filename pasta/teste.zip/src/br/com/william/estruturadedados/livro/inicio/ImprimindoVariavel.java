package br.com.william.estruturadedados.livro.inicio;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author John William Vicente
 */
public class ImprimindoVariavel {
    //Apenas uma linha
    /*
    MAis de uma linha
    */
    /***
     * 
     * @param args parametro de entrada do metodo main 
     */
    public static void main(String[] args) {
        /*
        TIPOS PRIMITIDOS:
        int 
        double
        float
        short
        long
        char
        bit
        boolean
        */
        int idade=10;
        System.out.println(idade);
        System.out.println("OLA mundo !!!");
    }
}
