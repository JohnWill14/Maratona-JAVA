/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.william.k19.operadores;

/**
 *
 * @author usuario
 */
public class Booleanos {
    public static void main(String[] args) {
        boolean test1=10==10;
        boolean test2=10!=11;
        boolean test3=10!=10;
        System.out.println(
                "Test 1=> "+test1+
                "\nTest 2=> "+test2+
                "\nTest 3=> "+test3
                   
        );
    }
}
