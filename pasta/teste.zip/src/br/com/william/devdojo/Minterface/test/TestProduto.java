/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.william.devdojo.Minterface.test;

import br.com.william.devdojo.Minterface.classe.Produto;

/**
 *
 * @author usuario
 */
public class TestProduto {
    public static void main(String[] args) {
        Produto p=new Produto();
        p.imprime();
    }
}
